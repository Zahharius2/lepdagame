
extends Node

var current_room_index: int = 1
