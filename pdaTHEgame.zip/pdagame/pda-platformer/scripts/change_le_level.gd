extends Area2D

func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("player"):
		Roomcount.current_room_index += 1
		var next_room_path = "res://rooms/room%d.tscn" % Roomcount.current_room_index
		if ResourceLoader.exists(next_room_path):  # Проверяем, существует ли сцена
			get_tree().change_scene_to_file(next_room_path)
		else:
			print("Сцена не найдена:", next_room_path)
			# Можно здесь загрузить меню, концовку или зациклить уровни
