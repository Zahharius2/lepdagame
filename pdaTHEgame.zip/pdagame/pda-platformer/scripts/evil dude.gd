extends CharacterBody2D

@export var speed: float  # Horizontal speed
@export var gravity: float = 1000  # Gravity strength

func _ready() -> void:
	scale.x = -1
	add_to_group("enemy") 

func _process(delta):
	velocity.x = speed * delta
	if not is_on_floor():
		velocity.y += gravity * delta 
	if velocity.y > 1000:
		velocity.y = 1000
	move_and_slide()

func _on_wall_body_entered(body):
	speed = -speed
	scale.x = -1
	if body.is_in_group("player"):
		print("u died")
		get_tree().reload_current_scene()
