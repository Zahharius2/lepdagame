extends Area2D

func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("player"):
		print("berry collected pog")
		queue_free()
		var finih = get_parent().get_node("finih")
		if finih:
			finih.queue_free()
