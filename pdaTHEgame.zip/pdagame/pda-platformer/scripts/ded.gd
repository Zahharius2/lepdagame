extends Area2D

func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("player"):
		print("u died")
		get_tree().reload_current_scene()
	if body.is_in_group("enemy"):
		emit_signal("enemy_entered", body)
		body.queue_free()
		print("he died lolololo")
		
