extends StaticBody2D

# Скорость перемещения
var velocity = Vector2(-300, 0)  # движение влево с 300 пикселями в секунду

func _process(delta):
	# Изменяем позицию платформы вручную
	position += velocity * delta
