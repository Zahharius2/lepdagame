extends Area2D

func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("player"):
		SoundManager.play_sound("fake as hell", global_position)
