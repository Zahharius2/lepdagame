extends Area2D

@export var launch_force = 1000
@export var override_force: int = -1
@export var launch_force_enemy = 800

@onready var sprite = $AnimatedSprite2D



func _on_body_entered(body):

	if body.is_in_group("player"):
		SoundManager.play_sound("spring", global_position)
			
		# Only trigger if player is falling
		if body.velocity.y >= 0:
			body.velocity.y = -launch_force
			
			# reset double jump
			body.jump_count = 0 
			body.is_jumping = false
			# play animation
			if sprite:
				sprite.play("action")
				await sprite.animation_finished
				sprite.play("idle")
				
	if body.is_in_group("enemy"):
		SoundManager.play_sound("spring", global_position)
		if body.velocity.y >= 0:

			body.velocity.y = -launch_force_enemy
			
			
