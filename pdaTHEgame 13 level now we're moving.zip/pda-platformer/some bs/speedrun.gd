extends CanvasLayer
 
var time: float = Globaltime.speedrun_time
var stop_room := 14
var finished := false

func save_time_to_file():
	var formatted_time = "%.2f" % time
	
	# Get current date and time
	var datetime = Time.get_datetime_dict_from_system()
	
	var year = str(datetime.year)
	var month = str(datetime.month).pad_zeros(2)
	var day = str(datetime.day).pad_zeros(2)
	var hour = str(datetime.hour)
	var minute = str(datetime.minute).pad_zeros(2)
	
	var timestamp = "%s/%s/%s %s:%s" % [year, month, day, hour, minute]
	
	var line = "%s (%s)" % [formatted_time, timestamp]
	
	var path = "res://speedrun_time.txt"
	var file
	
	if FileAccess.file_exists(path):
		file = FileAccess.open(path, FileAccess.READ_WRITE)
		file.seek_end()
	else:
		file = FileAccess.open(path, FileAccess.WRITE)
	
	if file:
		file.store_line(line)
		file.close()
func _ready():
	var font: Font = load("res://impact.ttf")
	$Label.add_theme_font_override("font", font)
	$Label.add_theme_color_override("font_outline_color", Color.BLACK)
	$Label.add_theme_constant_override("outline_size", 4)
	$Label.add_theme_font_size_override("font_size", 24)
	
func _physics_process(delta):
	if finished:
		return
		
	if Roomcount.current_room_index >= stop_room:
		finished = true
		save_time_to_file()
	else:
		time += delta
		Globaltime.speedrun_time = time
	
	update_ui()
 
func update_ui():
	var formatted_time = "%.2f" % time
	$Label.text = formatted_time
	
