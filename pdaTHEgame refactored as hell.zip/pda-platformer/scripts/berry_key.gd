extends Area2D

func _on_body_entered(body: Node2D) -> void:
	if GameLogic.is_player_body(body):
		print("berry collected pog")
		queue_free()
		SoundManager.play_sound("berry", global_position)
		var finih = get_parent().get_node("finih")
		if finih:
			finih.queue_free()
