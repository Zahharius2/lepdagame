extends Area2D

func _on_body_entered(body: Node2D) -> void:
	if GameLogic.is_player_body(body):
		SoundManager.play_sound("fake as hell", global_position)
