extends Area2D

func _on_body_entered(body: Node2D) -> void:
	if GameLogic.is_player_body(body):
		get_tree().quit()
		
