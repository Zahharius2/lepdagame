extends Area2D

func _on_body_entered(body: Node2D) -> void:
	if GameLogic.is_player_body(body):
		print("u died")
		SoundManager.play_sound("death", global_position)
		get_tree().reload_current_scene()
	if GameLogic.is_enemy_body(body):
		emit_signal("enemy_entered", body)
		body.queue_free()
		print("he died lolololo")
		
