extends Area2D

@export var launch_force = 1000
@export var override_force: int = -1
@export var launch_force_enemy = 800

@onready var sprite = $AnimatedSprite2D



func _on_body_entered(body):

	if GameLogic.is_player_body(body):
		SoundManager.play_sound("spring", global_position)
			
		# Only trigger if player is falling
		if GameLogic.should_launch_from_spring(body.velocity.y):
			body.velocity.y = GameLogic.compute_spring_launch_velocity(body.velocity.y, launch_force)
			
			# reset double jump
			body.jump_count = 0 
			body.is_jumping = false
			# play animation
			if sprite:
				sprite.play("action")
				await sprite.animation_finished
				sprite.play("idle")
				
	if GameLogic.is_enemy_body(body):
		SoundManager.play_sound("spring", global_position)
		if GameLogic.should_launch_from_spring(body.velocity.y):

			body.velocity.y = GameLogic.compute_spring_launch_velocity(body.velocity.y, launch_force_enemy)
			
			
