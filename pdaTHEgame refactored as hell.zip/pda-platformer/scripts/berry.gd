extends Area2D
@onready var sound = $AudioStreamPlayer2D
func _on_body_entered(body: Node2D) -> void:
	if GameLogic.should_collect_berry(body.is_in_group("player")):
		print("berry collected pog")
		SoundManager.play_sound("berry", global_position)
		queue_free()
