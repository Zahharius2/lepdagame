extends Node2D

func _ready():
	GlobalAudioStreamPlayer.play_music_level()
