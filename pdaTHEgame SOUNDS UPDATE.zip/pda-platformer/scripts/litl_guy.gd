extends CharacterBody2D

@onready var _animated_sprite = $AnimatedSprite2D
@export var speed = 300
@export var gravity = 30
@export var jump_force = 600
@export var max_jumps = 2


var jump_count = 0
var is_jumping = false

func _physics_process(delta):
	if !is_on_floor():
		velocity.y += gravity
		if velocity.y > 1000:
			velocity.y = 1000
	else:
		jump_count = 0
		is_jumping = false
		if Input.is_action_pressed("move_left") or Input.is_action_pressed("move_right"):
			_animated_sprite.play("walking")
		else:
			_animated_sprite.play('idle')

	if Input.is_action_just_pressed("jump") and jump_count < max_jumps:
		_animated_sprite.play("jumping")
		SoundManager.play_sound("jump", global_position)
		if jump_count == 1:
			velocity.y = -(jump_force - 200)
		else:
			velocity.y = -jump_force
		jump_count += 1

	var horizontal_direction = Input.get_axis("move_left", "move_right")
	velocity.x = speed * horizontal_direction
	move_and_slide()

	if horizontal_direction < 0:
		_animated_sprite.scale.x = -1  
	elif horizontal_direction > 0:
		_animated_sprite.scale.x = 1  


func _on_death_body_entered(body: Node2D) -> void:
	pass # Replace with function body.
func _ready():
	add_to_group("player")
	


func _on_change_le_level_body_entered(body: Node2D) -> void:
	pass # Replace with function body.
