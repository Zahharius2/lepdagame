extends Node

var sounds = {}

func _ready():
	# Preload sounds here
	sounds["berry"] = preload("res://music and sounds/sound_pdascore.wav")
	sounds["death"] = preload("res://music and sounds/sound_pdadeath.wav")
	sounds["spring"] =preload("res://music and sounds/sound_pdaspringus.wav")
	sounds["jump"] = preload("res://music and sounds/sound_jump.wav")
	sounds["victory"] = preload("res://music and sounds/sound_pdapop.wav")
func play_sound(name: String, position: Vector2 = Vector2.ZERO):
	if not sounds.has(name):
		print("Sound not found:", name)
		return
	
	var player = AudioStreamPlayer2D.new()
	player.stream = sounds[name]
	player.global_position = position
	
	add_child(player)
	player.play()
	
	player.finished.connect(player.queue_free)
