
extends Node

# Tracks the active room index so level transitions can build the next scene path.
var current_room_index: int = 1
