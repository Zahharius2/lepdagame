extends Node

# Global shared state for the project. Currently used for the speedrun timer.
var speedrun_time = 0
