extends Node

# Central sound registry so scenes only need to pass a sound key.
var sounds = {}

func _ready():
	# Preload the effects once so playback stays fast during gameplay.
	sounds["berry"] = preload("res://music and sounds/sound_pdascore.wav")
	sounds["death"] = preload("res://music and sounds/sound_pdadeath.wav")
	sounds["spring"] = preload("res://music and sounds/sound_pdaspringus.wav")
	sounds["jump"] = preload("res://music and sounds/sound_jump.wav")
	sounds["victory"] = preload("res://music and sounds/sound_pdapop.wav")
	sounds["fake as hell"] = preload("res://music and sounds/NUH UH.mp3")
	
func play_sound(name: String, position: Vector2 = Vector2.ZERO):
	if not sounds.has(name):
		print("Sound not found:", name)
		return
	
	# Spawn a one-shot player at the requested position and clean it up after playback.
	var player = AudioStreamPlayer2D.new()
	player.stream = sounds[name]
	player.global_position = position
	
	add_child(player)
	player.play()
	
	player.finished.connect(player.queue_free)
