extends Node

var failures := 0


func _ready() -> void:
	_run_all_tests()
	if failures == 0:
		print("All tests passed")
	else:
		push_error("Tests failed: %d" % failures)

	get_tree().quit(1 if failures > 0 else 0)


func _run_all_tests() -> void:
	_test_build_room_scene_path()
	_test_format_speedrun_time()
	_test_build_speedrun_entry()
	_test_should_launch_from_spring()
	_test_compute_spring_launch_velocity()
	_test_player_jump_velocity()
	_test_should_collect_berry()
	_test_player_and_enemy_body_checks()

	# Integration tests: instantiate scenes and verify basic composition/connection
	var integration = load("res://tests/integration_tests.gd").new()
	integration.run(Callable(self, "_expect_equal"))


func _expect_equal(actual, expected, test_name: String) -> void:
	if actual == expected:
		print("PASS: %s" % test_name)
		return

	failures += 1
	push_error("FAIL: %s | expected %s, got %s" % [test_name, expected, actual])


func _test_build_room_scene_path() -> void:
	_expect_equal(GameLogic.build_room_scene_path(1), "res://rooms/room1.tscn", "build_room_scene_path(1)")
	_expect_equal(GameLogic.build_room_scene_path(13), "res://rooms/room13.tscn", "build_room_scene_path(13)")


func _test_format_speedrun_time() -> void:
	_expect_equal(GameLogic.format_speedrun_time(0.0), "0.00", "format_speedrun_time(0.0)")
	_expect_equal(GameLogic.format_speedrun_time(12.345), "12.35", "format_speedrun_time(12.345)")


func _test_build_speedrun_entry() -> void:
	var datetime := {
		"year": 2026,
		"month": 5,
		"day": 12,
		"hour": 7,
		"minute": 3,
	}
	_expect_equal(
		GameLogic.build_speedrun_entry(9.1, datetime),
		"9.10 (2026/05/12 7:03)",
		"build_speedrun_entry()"
	)


func _test_should_launch_from_spring() -> void:
	_expect_equal(GameLogic.should_launch_from_spring(0.0), true, "should_launch_from_spring(0.0)")
	_expect_equal(GameLogic.should_launch_from_spring(-1.0), false, "should_launch_from_spring(-1.0)")


func _test_compute_spring_launch_velocity() -> void:
	_expect_equal(GameLogic.compute_spring_launch_velocity(12.0, 1000), -1000.0, "compute_spring_launch_velocity(falling)")
	_expect_equal(GameLogic.compute_spring_launch_velocity(-3.0, 1000), -3.0, "compute_spring_launch_velocity(rising)")


func _test_player_jump_velocity() -> void:
	_expect_equal(GameLogic.player_jump_velocity(0, 600), -600.0, "player_jump_velocity(first jump)")
	_expect_equal(GameLogic.player_jump_velocity(1, 600), -400.0, "player_jump_velocity(second jump)")


func _test_should_collect_berry() -> void:
	_expect_equal(GameLogic.should_collect_berry(true), true, "should_collect_berry(true)")
	_expect_equal(GameLogic.should_collect_berry(false), false, "should_collect_berry(false)")


func _test_player_and_enemy_body_checks() -> void:
	var player := Node.new()
	player.add_to_group("player")
	var enemy := Node.new()
	enemy.add_to_group("enemy")
	var neutral := Node.new()

	_expect_equal(GameLogic.is_player_body(player), true, "is_player_body(player)")
	_expect_equal(GameLogic.is_player_body(neutral), false, "is_player_body(neutral)")
	_expect_equal(GameLogic.is_enemy_body(enemy), true, "is_enemy_body(enemy)")
	_expect_equal(GameLogic.is_enemy_body(neutral), false, "is_enemy_body(neutral)")
