extends Node

func run(expect: Callable) -> void:
	# Load and instantiate the main room scene, check it contains the player instance
	var room_scene = load("res://rooms/room.tscn")
	expect.call(room_scene != null, true, "load room.tscn")
	var room = room_scene.instantiate()

	expect.call(room.has_node("litl guy"), true, "room contains 'litl guy'")
	var litl = room.get_node("litl guy")
	expect.call(litl.is_in_group("player"), true, "'litl guy' in group 'player'")

	# Load and instantiate the berry area, check expected children and signal connection
	var berry_scene = load("res://rooms/berry.tscn")
	expect.call(berry_scene != null, true, "load berry.tscn")
	var berry = berry_scene.instantiate()

	expect.call(berry.has_node("CollisionShape2D"), true, "berry has CollisionShape2D")
	expect.call(berry.has_node("Sprite2D"), true, "berry has Sprite2D")
