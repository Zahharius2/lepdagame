extends Area2D
# Collectible berry: when the player touches it, play the pickup sound and remove the node.
@onready var sound = $AudioStreamPlayer2D
func _on_body_entered(body: Node2D) -> void:
	if GameLogic.should_collect_berry(body.is_in_group("player")):
		# The pickup is handled through the shared sound manager so the effect stays consistent.
		SoundManager.play_sound("berry", global_position)
		print("berry collected pog")
		queue_free()
