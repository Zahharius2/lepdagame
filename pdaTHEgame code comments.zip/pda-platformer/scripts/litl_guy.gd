extends CharacterBody2D

# Player controller: handles movement, double jump, animation, and facing direction.
@onready var _animated_sprite = $AnimatedSprite2D
@export var speed = 300
@export var gravity = 30
@export var jump_force = 600
@export var max_jumps = 2


var jump_count = 0
var is_jumping = false

func _physics_process(delta):
	if !is_on_floor():
		# Apply gravity while airborne and clamp the fall speed so the player stays controllable.
		velocity.y += gravity
		if velocity.y > 1000:
			velocity.y = 1000
	else:
		# Reset jump state on the ground and switch the sprite to a ground animation.
		jump_count = 0
		is_jumping = false
		if Input.is_action_pressed("move_left") or Input.is_action_pressed("move_right"):
			_animated_sprite.play("walking")
		else:
			_animated_sprite.play('idle')

	if Input.is_action_just_pressed("jump") and jump_count < max_jumps:
		# Jump force comes from shared game logic so the first and second jump stay consistent.
		_animated_sprite.play("jumping")
		SoundManager.play_sound("jump", global_position)
		velocity.y = GameLogic.player_jump_velocity(jump_count, jump_force)
		jump_count += 1

	# Horizontal movement is driven directly by input and the sprite is flipped to match direction.
	var horizontal_direction = Input.get_axis("move_left", "move_right")
	velocity.x = speed * horizontal_direction
	move_and_slide()

	if horizontal_direction < 0:
		_animated_sprite.scale.x = -1  
	elif horizontal_direction > 0:
		_animated_sprite.scale.x = 1  


func _on_death_body_entered(body: Node2D) -> void:
	pass # Replace with function body.
func _ready():
	# Mark this node as the player so hazards can detect it without hard references.
	add_to_group("player")
	


func _on_change_le_level_body_entered(body: Node2D) -> void:
	pass # Replace with function body.
