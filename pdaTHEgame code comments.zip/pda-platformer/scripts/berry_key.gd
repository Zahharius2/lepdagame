extends Area2D

# Collectible berry variant with a special key trigger: picks up the berry, plays sound, and removes big red door near finish flag location
func _on_body_entered(body: Node2D) -> void:
	if GameLogic.is_player_body(body):
		# Play pickup sound and remove the berry.
		SoundManager.play_sound("berry", global_position)
		queue_free()
		# Clean up the end-level node so the level can end.
		var finih = get_parent().get_node("finih")
		if finih:
			finih.queue_free()
