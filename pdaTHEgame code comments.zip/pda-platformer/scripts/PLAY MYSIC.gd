extends Node2D

# Scene hook that starts the level music as soon as the room loads.
func _ready():
	GlobalAudioStreamPlayer.play_music_level()
