extends Area2D

# Level exit trigger: only the player can advance to the next room.
func _on_body_entered(body: Node2D) -> void:
	if GameLogic.is_player_body(body):
		SoundManager.play_sound("victory", global_position)
		Roomcount.current_room_index += 1
		var next_room_path = GameLogic.build_room_scene_path(Roomcount.current_room_index)
		# Only change scenes when the next room exists, otherwise the game keeps the current level.
		if ResourceLoader.exists(next_room_path):
			get_tree().change_scene_to_file(next_room_path)
		else:
			print("Scene not found:", next_room_path)
