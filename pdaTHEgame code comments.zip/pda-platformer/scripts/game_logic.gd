extends RefCounted
class_name GameLogic

# Pure helper functions used by scenes, triggers, and tests.
static func build_room_scene_path(room_index: int) -> String:
	return "res://rooms/room%d.tscn" % room_index

# Format the on-screen timer with two decimal places.
static func format_speedrun_time(time: float) -> String:
	return "%.2f" % time

# Convert a system datetime dictionary into the timestamp format used by the speedrun log.
static func build_speedrun_timestamp(datetime_dict: Dictionary) -> String:
	var year = str(datetime_dict.get("year", 0))
	var month = str(int(datetime_dict.get("month", 0))).pad_zeros(2)
	var day = str(int(datetime_dict.get("day", 0))).pad_zeros(2)
	var hour = str(int(datetime_dict.get("hour", 0)))
	var minute = str(int(datetime_dict.get("minute", 0))).pad_zeros(2)

	return "%s/%s/%s %s:%s" % [year, month, day, hour, minute]

# Build a single save-file entry that stores both the time and the timestamp.
static func build_speedrun_entry(time: float, datetime_dict: Dictionary) -> String:
	return "%s (%s)" % [format_speedrun_time(time), build_speedrun_timestamp(datetime_dict)]

# Springs should only launch the player or enemies when they are moving downward or standing still.
static func should_launch_from_spring(velocity_y: float) -> bool:
	return velocity_y >= 0.0

# A spring launch overrides downward speed so it always feels like a bounce.
static func compute_spring_launch_velocity(velocity_y: float, launch_force: float) -> float:
	if should_launch_from_spring(velocity_y):
		return -launch_force

	return velocity_y

# The second jump is intentionally weaker so double-jumping feels distinct from the first jump.
static func player_jump_velocity(jump_count: int, jump_force: float) -> float:
	if jump_count == 1:
		return -(jump_force - 200)

	return -jump_force

# Collectibles only care whether the collider belongs to the player.
static func should_collect_berry(body_is_player: bool) -> bool:
	return body_is_player

# These helpers centralize group checks so hazards and triggers use the same rule.
static func is_player_body(body: Node) -> bool:
	return body != null and body.is_in_group("player")

static func is_enemy_body(body: Node) -> bool:
	return body != null and body.is_in_group("enemy")
