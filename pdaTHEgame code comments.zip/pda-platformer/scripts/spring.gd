extends Area2D

# Spring pad: launches the player or enemies upward, with separate forces for each.
@export var launch_force = 1000
@export var override_force: int = -1
@export var launch_force_enemy = 800

@onready var sprite = $AnimatedSprite2D



func _on_body_entered(body):

	if GameLogic.is_player_body(body):
		SoundManager.play_sound("spring", global_position)
			
		# Only bounce the player if they are not already moving upward.
		if GameLogic.should_launch_from_spring(body.velocity.y):
			body.velocity.y = GameLogic.compute_spring_launch_velocity(body.velocity.y, launch_force)
			
			# Reset jump state so the bounce becomes the start of a new jump sequence.
			body.jump_count = 0 
			body.is_jumping = false
			# Play the spring animation if the scene has a sprite attached.
			if sprite:
				sprite.play("action")
				await sprite.animation_finished
				sprite.play("idle")
				
	#if enemy is on a spring he bounces too
	if GameLogic.is_enemy_body(body):
		SoundManager.play_sound("spring", global_position)
		if GameLogic.should_launch_from_spring(body.velocity.y):

			body.velocity.y = GameLogic.compute_spring_launch_velocity(body.velocity.y, launch_force_enemy)
			
			
