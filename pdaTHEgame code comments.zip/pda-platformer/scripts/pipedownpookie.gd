extends CharacterBody2D

# Patrolling enemy that flips direction on walls and restarts the room when it catches the player.
@export var speed: float  # Horizontal speed
@export var gravity: float = 1000  # Gravity strength

func _ready() -> void:
	# Enemy group membership lets shared helper code detect this body.
	scale.x = -1
	add_to_group("enemy") 

func _process(delta):
	velocity.x = speed * delta
	if not is_on_floor():
		velocity.y += gravity * delta 
	if velocity.y > 1000:
		velocity.y = 1000
	move_and_slide()

func _on_wall_body_entered(body):
	# Turn around on every wall hit so the enemy keeps patrolling.
	speed = -speed
	scale.x = -1
	if GameLogic.is_player_body(body):
		get_tree().reload_current_scene()
