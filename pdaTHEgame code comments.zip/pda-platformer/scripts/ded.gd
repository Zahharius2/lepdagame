extends Area2D

# Death zone: restart the current room when the player touches it, and clean up enemies that fall into it.
func _on_body_entered(body: Node2D) -> void:
	if GameLogic.is_player_body(body):
		SoundManager.play_sound("death", global_position)
		print("u died")
		get_tree().reload_current_scene()
	if GameLogic.is_enemy_body(body):
		# Enemies are removed instead of reloading the level so hazards can be placed off-screen.
		emit_signal("enemy_entered", body)
		print("he died lolololo")
		body.queue_free()
		
