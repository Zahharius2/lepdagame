extends AudioStreamPlayer

# Dedicated music player used by the autoload to keep level music persistent between scenes.
const level_music = preload("res://music and sounds/Alien Hominid Music - PDA game.mp3")

func _play_music(music: AudioStream, volume = 0.0):
	# Avoid restarting the same track if it is already playing.
	if stream == music:
		return
	
	stream = music
	volume_db = volume
	play()
	
func play_music_level():
	# Start the default level music.
	_play_music(level_music)
	
